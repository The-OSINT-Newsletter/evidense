import { App, TFolder, TFile, Notice } from 'obsidian';

export interface Identifier {
  type: 'name' | 'email' | 'phone' | 'username' | 'domain' | 'image';
  value: string;
  dateAdded: string;
  notes?: string;
}

export interface Case {
  id: string;
  name: string;
  description: string;
  createdDate: string;
  identifiers: Identifier[];
}

export class CaseManager {
  app: App;
  caseFolder: string;

  constructor(app: App, caseFolder: string) {
    this.app = app;
    this.caseFolder = caseFolder;
  }

  async ensureCaseFolder(): Promise<TFolder> {
    const root = this.app.vault.getRoot();
    let folder = this.app.vault.getFolderByPath(this.caseFolder);
    
    if (!folder) {
      folder = await this.app.vault.createFolder(this.caseFolder);
    }
    
    return folder;
  }

  async createCase(name: string, description: string): Promise<string> {
    const caseFolder = await this.ensureCaseFolder();
    
    // Generate case ID
    const caseId = `case-${Date.now()}`;
    
    // Create case subfolder
    const casePath = `${this.caseFolder}/${name}`;
    const newCaseFolder = await this.app.vault.createFolder(casePath);
    
    // Create case metadata file
    const caseData: Case = {
      id: caseId,
      name: name,
      description: description,
      createdDate: new Date().toISOString(),
      identifiers: []
    };

    const metadataPath = `${casePath}/case.json`;
    await this.app.vault.create(metadataPath, JSON.stringify(caseData, null, 2));

    // Create individual identifier type files
    const identifierTypes = [
      { name: 'names', title: 'Names' },
      { name: 'emails', title: 'Email Addresses' },
      { name: 'phones', title: 'Phone Numbers' },
      { name: 'usernames', title: 'Usernames' },
      { name: 'domains', title: 'Domains' },
      { name: 'images', title: 'Images' }
    ];

    for (const type of identifierTypes) {
      const filePath = `${casePath}/${type.name}.md`;
      const content = `# ${type.title}

`;
      await this.app.vault.create(filePath, content);
    }

    // Create case notes file
    const notesPath = `${casePath}/notes.md`;
    const notesContent = `# Case Notes - ${name}

## Observations
- 

## Theories
- 

## Next Steps
- 

## Timeline
- 
`;
    await this.app.vault.create(notesPath, notesContent);

    new Notice(`Case "${name}" created successfully`);
    return caseId;
  }

  async getCaseByPath(casePath: string): Promise<Case | null> {
    try {
      const metadataFile = this.app.vault.getFileByPath(`${casePath}/case.json`);
      if (!metadataFile) {
        return null;
      }
      
      const content = await this.app.vault.read(metadataFile);
      return JSON.parse(content);
    } catch (error) {
      console.error('Error reading case:', error);
      return null;
    }
  }

  async addIdentifier(casePath: string, identifier: Identifier): Promise<void> {
    try {
      // Update JSON metadata
      const metadataFile = this.app.vault.getFileByPath(`${casePath}/case.json`);
      if (metadataFile) {
        const content = await this.app.vault.read(metadataFile);
        const caseData: Case = JSON.parse(content);
        
        caseData.identifiers.push(identifier);
        
        await this.app.vault.modify(metadataFile, JSON.stringify(caseData, null, 2));
      }

      // Update the appropriate identifier type file
      const typeFileMap: { [key: string]: string } = {
        'name': 'names.md',
        'email': 'emails.md',
        'phone': 'phones.md',
        'username': 'usernames.md',
        'domain': 'domains.md',
        'image': 'images.md'
      };

      const fileName = typeFileMap[identifier.type];
      const filePath = `${casePath}/${fileName}`;
      const file = this.app.vault.getFileByPath(filePath);
      
      if (file) {
        let content = await this.app.vault.read(file);
        
        // Add new bullet point with link
        const newEntry = `- [[${identifier.value}]]\n`;
        content += newEntry;

        await this.app.vault.modify(file, content);
      }

      new Notice(`Identifier added successfully`);
    } catch (error) {
      console.error('Error adding identifier:', error);
      new Notice('Error adding identifier');
    }
  }

  async getAllCases(): Promise<Array<{ name: string; path: string }>> {
    const caseFolder = await this.ensureCaseFolder();
    const cases: Array<{ name: string; path: string }> = [];
    
    const children = caseFolder.children;
    for (const child of children) {
      if (child instanceof TFolder && child.name !== '.') {
        cases.push({ name: child.name, path: child.path });
      }
    }
    
    return cases;
  }

  async searchIdentifiers(searchTerm: string): Promise<Array<{ caseName: string; type: string; value: string; notes?: string }>> {
    const results: Array<{ caseName: string; type: string; value: string; notes?: string }> = [];
    const cases = await this.getAllCases();

    for (const caseItem of cases) {
      const typeFiles = ['names', 'emails', 'phones', 'usernames', 'domains', 'images'];
      
      for (const type of typeFiles) {
        const file = this.app.vault.getFileByPath(`${caseItem.path}/${type}.md`);
        if (file) {
          const content = await this.app.vault.read(file);
          const lines = content.split('\n');
          
          for (const line of lines) {
            if (line.includes(searchTerm) && line.startsWith('- ')) {
              const value = line.replace('- ', '').trim();
              if (value) {
                results.push({
                  caseName: caseItem.name,
                  type: type,
                  value: value
                });
              }
            }
          }
        }
      }
    }

    return results;
  }
}
