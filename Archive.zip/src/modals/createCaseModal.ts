import { App, Modal, Setting } from 'obsidian';
import { CaseManager } from '../caseManager';

export class CreateCaseModal extends Modal {
  caseManager: CaseManager;
  caseName: string = '';
  caseDescription: string = '';

  constructor(app: App, caseManager: CaseManager) {
    super(app);
    this.caseManager = caseManager;
  }

  onOpen() {
    const { contentEl } = this;
    contentEl.createEl('h2', { text: 'Create New Case' });

    new Setting(contentEl)
      .setName('Case Name')
      .setDesc('Enter a name for the case')
      .addText(text => text
        .setPlaceholder('e.g., Person Search - John Doe')
        .onChange(value => {
          this.caseName = value;
        }));

    new Setting(contentEl)
      .setName('Description')
      .setDesc('Brief description of the case')
      .addTextArea(text => text
        .setPlaceholder('Case details...')
        .onChange(value => {
          this.caseDescription = value;
        }));

    new Setting(contentEl)
      .addButton(btn => btn
        .setButtonText('Create Case')
        .setCta()
        .onClick(async () => {
          if (!this.caseName.trim()) {
            alert('Case name is required');
            return;
          }
          
          await this.caseManager.createCase(this.caseName, this.caseDescription);
          this.close();
        }))
      .addButton(btn => btn
        .setButtonText('Cancel')
        .onClick(() => {
          this.close();
        }));
  }

  onClose() {
    const { contentEl } = this;
    contentEl.empty();
  }
}
