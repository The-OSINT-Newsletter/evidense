import { App, Modal, Setting, Notice } from 'obsidian';
import { CaseManager } from '../caseManager';

export class SearchIdentifierModal extends Modal {
  caseManager: CaseManager;
  searchTerm: string = '';
  results: Array<{ caseName: string; type: string; value: string; notes?: string }> = [];

  constructor(app: App, caseManager: CaseManager) {
    super(app);
    this.caseManager = caseManager;
  }

  onOpen() {
    const { contentEl } = this;
    contentEl.createEl('h2', { text: 'Search Identifiers Across Cases' });

    new Setting(contentEl)
      .setName('Search Term')
      .setDesc('Enter a name, email, domain, or any identifier to search for')
      .addText(text => text
        .setPlaceholder('e.g., john@example.com or jakecreps.com')
        .onChange(value => {
          this.searchTerm = value;
        }));

    new Setting(contentEl)
      .addButton(btn => btn
        .setButtonText('Search')
        .setCta()
        .onClick(async () => {
          if (!this.searchTerm.trim()) {
            new Notice('Please enter a search term');
            return;
          }

          this.results = await this.caseManager.searchIdentifiers(this.searchTerm);
          this.displayResults();
        }))
      .addButton(btn => btn
        .setButtonText('Close')
        .onClick(() => this.close()));

    // Results container
    const resultsContainer = contentEl.createDiv('search-results');
    resultsContainer.id = 'search-results-container';
  }

  private displayResults() {
    const container = this.contentEl.querySelector('#search-results-container');
    if (!container) return;

    container.empty();

    if (this.results.length === 0) {
      container.createEl('p', { text: 'No results found for: ' + this.searchTerm });
      return;
    }

    container.createEl('h3', { text: `Found ${this.results.length} match(es)` });

    const resultsList = container.createEl('ul');
    for (const result of this.results) {
      const item = resultsList.createEl('li');
      const text = `[${result.caseName}] ${result.type.toUpperCase()}: ${result.value}`;
      const span = item.createEl('span', { text: text });
      
      if (result.notes) {
        item.createEl('small', { text: ` — ${result.notes}` });
      }
    }
  }

  onClose() {
    const { contentEl } = this;
    contentEl.empty();
  }
}
