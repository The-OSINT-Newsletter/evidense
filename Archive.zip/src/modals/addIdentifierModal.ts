import { App, Modal, Setting } from 'obsidian';
import { CaseManager, Identifier } from '../caseManager';

export class AddIdentifierModal extends Modal {
  caseManager: CaseManager;
  selectedCase: string = '';
  identifierType: 'name' | 'email' | 'phone' | 'username' | 'domain' | 'image' = 'name';
  identifierValue: string = '';
  identifierNotes: string = '';
  cases: Array<{ name: string; path: string }> = [];

  constructor(app: App, caseManager: CaseManager) {
    super(app);
    this.caseManager = caseManager;
  }

  async onOpen() {
    const { contentEl } = this;
    contentEl.createEl('h2', { text: 'Add Identifier to Case' });

    // Load available cases
    this.cases = await this.caseManager.getAllCases();

    if (this.cases.length === 0) {
      contentEl.createEl('p', { text: 'No cases found. Please create a case first.' });
      new Setting(contentEl)
        .addButton(btn => btn
          .setButtonText('Close')
          .onClick(() => this.close()));
      return;
    }

    // Case selection
    new Setting(contentEl)
      .setName('Select Case')
      .setDesc('Choose which case to add the identifier to')
      .addDropdown(dropdown => {
        this.cases.forEach(caseItem => {
          dropdown.addOption(caseItem.path, caseItem.name);
        });
        dropdown.onChange(value => {
          this.selectedCase = value;
        });
        // Set first case as default
        if (this.cases.length > 0) {
          dropdown.setValue(this.cases[0].path);
          this.selectedCase = this.cases[0].path;
        }
      });

    // Identifier type
    new Setting(contentEl)
      .setName('Identifier Type')
      .setDesc('What type of identifier are you adding?')
      .addDropdown(dropdown => {
        const types = ['name', 'email', 'phone', 'username', 'domain', 'image'];
        types.forEach(type => {
          dropdown.addOption(type, type.charAt(0).toUpperCase() + type.slice(1));
        });
        dropdown.onChange(value => {
          this.identifierType = value as any;
        });
        dropdown.setValue('name');
      });

    // Identifier value
    new Setting(contentEl)
      .setName('Value')
      .setDesc('The actual identifier value')
      .addText(text => text
        .setPlaceholder('Enter identifier...')
        .onChange(value => {
          this.identifierValue = value;
        }));

    // Notes
    new Setting(contentEl)
      .setName('Notes')
      .setDesc('Optional notes about this identifier')
      .addTextArea(text => text
        .setPlaceholder('e.g., Found in Twitter profile, verified on...')
        .onChange(value => {
          this.identifierNotes = value;
        }));

    // Buttons
    new Setting(contentEl)
      .addButton(btn => btn
        .setButtonText('Add Identifier')
        .setCta()
        .onClick(async () => {
          if (!this.identifierValue.trim()) {
            alert('Identifier value is required');
            return;
          }

          const identifier: Identifier = {
            type: this.identifierType,
            value: this.identifierValue,
            dateAdded: new Date().toISOString(),
            notes: this.identifierNotes || undefined
          };

          await this.caseManager.addIdentifier(this.selectedCase, identifier);
          this.close();
        }))
      .addButton(btn => btn
        .setButtonText('Cancel')
        .onClick(() => {
          this.close();
        }));
  }

  onClose() {
    const { contentEl } = this;
    contentEl.empty();
  }
}
