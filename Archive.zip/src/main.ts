import { App, Plugin, PluginSettingTab, Setting, Notice, Modal, TFolder } from 'obsidian';
import { CaseManager } from './caseManager';
import { CreateCaseModal } from './modals/createCaseModal';
import { AddIdentifierModal } from './modals/addIdentifierModal';
import { SearchIdentifierModal } from './modals/searchModal';

interface EvidenceSettings {
  caseFolder: string;
}

const DEFAULT_SETTINGS: EvidenceSettings = {
  caseFolder: 'Cases'
};

export default class EvidenceCaseManagerPlugin extends Plugin {
  settings!: EvidenceSettings;
  caseManager!: CaseManager;

  async onload() {
    await this.loadSettings();
    
    this.caseManager = new CaseManager(this.app, this.settings.caseFolder);

    // Add command to create new case
    this.addCommand({
      id: 'create-new-case',
      name: 'Create New Case',
      callback: () => {
        new CreateCaseModal(this.app, this.caseManager).open();
      }
    });

    // Add command to add identifier to case
    this.addCommand({
      id: 'add-identifier',
      name: 'Add Identifier to Case',
      callback: () => {
        new AddIdentifierModal(this.app, this.caseManager).open();
      }
    });

    // Add command to search identifiers
    this.addCommand({
      id: 'search-identifiers',
      name: 'Search Identifiers Across Cases',
      callback: () => {
        new SearchIdentifierModal(this.app, this.caseManager).open();
      }
    });

    // Settings tab
    this.addSettingTab(new EvidenceSettingTab(this.app, this));

    console.log('Evidence Case Manager plugin loaded');
  }

  onunload() {
    console.log('Evidence Case Manager plugin unloaded');
  }

  async loadSettings() {
    this.settings = Object.assign({}, DEFAULT_SETTINGS, await this.loadData());
  }

  async saveSettings() {
    await this.saveData(this.settings);
  }
}

class EvidenceSettingTab extends PluginSettingTab {
  plugin: EvidenceCaseManagerPlugin;

  constructor(app: App, plugin: EvidenceCaseManagerPlugin) {
    super(app, plugin);
    this.plugin = plugin;
  }

  display(): void {
    const { containerEl } = this;

    containerEl.empty();

    new Setting(containerEl)
      .setName('Case Folder')
      .setDesc('Folder where case files will be stored')
      .addText(text => text
        .setPlaceholder('Cases')
        .setValue(this.plugin.settings.caseFolder)
        .onChange(async (value) => {
          this.plugin.settings.caseFolder = value;
          await this.plugin.saveSettings();
        }));
  }
}
